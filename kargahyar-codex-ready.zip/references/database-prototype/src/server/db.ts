import "server-only";
import { PrismaPg } from "@prisma/adapter-pg";
import { PrismaClient } from "../generated/prisma/client";

const globalForPrisma = globalThis as unknown as { prisma?: PrismaClient };
function buildClient() {
  const url = process.env.DATABASE_URL;
  if (!url) throw new Error("DATABASE_URL is not configured");
  return new PrismaClient({ adapter: new PrismaPg({ connectionString: url }) });
}
export const prisma = globalForPrisma.prisma ?? buildClient();
if (process.env.NODE_ENV !== "production") globalForPrisma.prisma = prisma;
