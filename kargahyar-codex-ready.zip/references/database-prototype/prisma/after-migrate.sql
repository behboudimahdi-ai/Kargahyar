-- Apply once after the initial Prisma migration. PostgreSQL CHECK constraints are not represented in Prisma schema.
ALTER TABLE "OrderItem" ADD CONSTRAINT "OrderItem_quantity_positive" CHECK (quantity > 0);
ALTER TABLE "ProductionBatch" ADD CONSTRAINT "ProductionBatch_plannedQty_positive" CHECK ("plannedQty" > 0);
ALTER TABLE "ProductionEntry" ADD CONSTRAINT "ProductionEntry_qty_valid" CHECK ("producedQty" > 0 AND "defectiveQty" >= 0 AND "defectiveQty" <= "producedQty");
ALTER TABLE "QualityIssue" ADD CONSTRAINT "QualityIssue_quantity_positive" CHECK (quantity > 0);
ALTER TABLE "Operation" ADD CONSTRAINT "Operation_standardSeconds_positive" CHECK ("standardSeconds" IS NULL OR "standardSeconds" > 0);
ALTER TABLE "ProductOperation" ADD CONSTRAINT "ProductOperation_sequence_positive" CHECK (sequence > 0);
ALTER TABLE "Attendance" ADD CONSTRAINT "Attendance_time_order" CHECK ("checkOut" IS NULL OR "checkIn" IS NULL OR "checkOut" >= "checkIn");
