import "dotenv/config";
import { PrismaPg } from "@prisma/adapter-pg";
import { PrismaClient } from "../src/generated/prisma/client";

const url = process.env.DATABASE_URL;
if (!url) throw new Error("DATABASE_URL is missing");
const prisma = new PrismaClient({ adapter: new PrismaPg({ connectionString: url }) });

async function main() {
  // Reference catalog only. No login/password, employee, order or production records created.
  const workshop = await prisma.workshop.findFirst({ where: { name: "کارگاه نمونه کارگاه‌یار" } })
    ?? await prisma.workshop.create({ data: { name: "کارگاه نمونه کارگاه‌یار" } });
  const operation = await prisma.operation.upsert({
    where: { workshopId_code: { workshopId: workshop.id, code: "SEW-001" } },
    create: { workshopId: workshop.id, code: "SEW-001", name: "راسته‌دوزی" },
    update: {},
  });
  const product = await prisma.productModel.upsert({
    where: { workshopId_code: { workshopId: workshop.id, code: "SH-001" } },
    create: { workshopId: workshop.id, code: "SH-001", name: "شومیز فری‌سایز تک‌جیب" },
    update: {},
  });
  await prisma.productOperation.upsert({
    where: { productId_sequence: { productId: product.id, sequence: 1 } },
    create: { productId: product.id, operationId: operation.id, sequence: 1 },
    update: {},
  });
  console.log("Demo catalog seeded; workshop:", workshop.id);
}
main().catch(err => { console.error(err); process.exitCode = 1; }).finally(async () => prisma.$disconnect());
