# KargahYar database — PostgreSQL 18 + Prisma 7

Standalone database foundation to copy into an existing **Next.js 16** project. This is NOT a complete application or deployed database.

## Prerequisites
- Windows + Node.js **24** + Docker Desktop (running; WSL2 configured)
- VS Code / terminal

## Windows PowerShell quickstart

```powershell
Copy-Item .env.example .env
# Edit .env: choose a strong unique password and set it in BOTH fields; URL-encode reserved URL characters or use alphanumeric password.
npm install
docker compose up -d
npm run db:validate
npm run db:migrate
npm run db:generate
npm run db:seed
npm run db:studio
```

For extra SQL CHECK constraints, run **after** Prisma migration:

```powershell
Get-Content prisma/after-migrate.sql | docker compose exec -T postgres psql -U kargahyar -d kargahyar -v ON_ERROR_STOP=1
```

`db:migrate` uses `prisma migrate dev --name init` and generates the local migration files. **Commit generated `prisma/migrations`**. For production use `npx prisma migrate deploy`, NOT `db push`.

**Never** run `docker compose down -v` on a database holding data: it deletes the persistent volume.

## Database architecture

- Workshop: tenant/workshop
- User, Membership, Employee: accounts, roles, workers
- Machine, Operation, ProductModel, ProductOperation: production master data
- ProductionOrder, OrderItem, ProductionBatch: customer orders and batches
- Assignment: worker-operation allocations
- ProductionEntry: operation-specific production counts and approvals
- QualityIssue: defect/rework tracking
- Attendance: timesheets
- AuditLog: change history

See `docs/DATA_RULES.md` for safety/integrity rules.

## Integrating into Next.js
Copy `prisma/`, `prisma.config.ts`, `src/server/db.ts` and `compose.yaml` into the Next.js project; install the dependencies from this package (or run `npm install prisma@7 @prisma/client@7 @prisma/adapter-pg pg dotenv` and `npm install -D tsx @types/pg`). The `src/server/db.ts` file uses `server-only`, available in Next.js; if using outside Next.js remove that import. Add Prisma-generated path to your application's `.gitignore`.

## Verification status
Files generated and manually inspected. Prisma CLI validation, dependency installation, Docker/database start and migrations must be run on your laptop; they were NOT run in this authoring environment.
