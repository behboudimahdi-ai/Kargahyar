# KargahYar — database business rules

- All queries MUST be scoped to the authenticated `workshopId`; foreign keys alone do not prevent cross-workshop references when IDs from other tenants are supplied. Enforce ownership checks in services, preferably in a single transaction.
- `ProductionEntry.producedQty` is the total units processed in ONE operation, not finished garments. `defectiveQty` is the defective subset (`0 <= defectiveQty <= producedQty`). Never sum entries across operations as finished goods.
- Production dashboards use **APPROVED** entries only. `goodQty = producedQty - defectiveQty`. Count completed garments ONLY for the final validated operation/explicit final inspection rule.
- `PENDING -> APPROVED/REJECTED` must be an atomic transition, with authenticated reviewer ID, timestamp and `AuditLog` written in the same transaction. A reviewer must be authorized for the workshop and cannot approve their own entries if segregation of duties applies.
- Submitted records are not hard-deleted. Corrections must create a compensating record or transition to VOIDED with documented approval and an audit trail. Do not blindly overwrite approved quantities.
- `clientKey` makes network retries idempotent; clients should submit a stable UUID per local form submission.
- Date-only fields use PostgreSQL DATE. All timestamps are stored as UTC and rendered in the workshop timezone. Jalali is a presentation concern, not a database date type.
- Quantity, status, and referential constraints must be checked at the database and service layers. Use the accompanying post-migration SQL constraints after migration.
- `ProductOperation` is the CURRENT route definition. Freeze a revision/snapshot per batch before changing industrial operation definitions in a live production system; the MVP assumes no mid-batch route mutation.
- Attendance entries are not payroll calculations. Payroll needs its own approved wage-policy/versioning domain in phase 2.
- Secrets must only be supplied via environment/secret manager. Never seed an owner account with a known password.
