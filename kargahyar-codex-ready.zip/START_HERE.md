# How to use this package with Codex

1. Open/create a Git repository named `kargahyar`.
2. Copy `KARGAHYAR_CODEX_HANDOFF.md`, `AGENTS.md` and (optionally) `references/` into the repository root, then commit them.
3. Open the repository in Codex (or in VS Code with the Codex extension).
4. Send this instruction: "Read AGENTS.md and KARGAHYAR_CODEX_HANDOFF.md. Inspect the repository and the reference database prototype. Implement Step 0 to Step 2, and then a secure working production vertical slice. Run real checks, and report actual results."

The `references/database-prototype` is a prototype only. Do not simply copy its package.json over the new Next.js project; inspect/validate before integration. No running database is included.
